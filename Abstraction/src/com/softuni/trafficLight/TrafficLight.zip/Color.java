package com.softuni.trafficLight;

public enum Color {
    RED,
    GREEN,
    YELLOW
}

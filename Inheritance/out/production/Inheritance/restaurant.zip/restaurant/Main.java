package restaurant;

public class Main {
}
